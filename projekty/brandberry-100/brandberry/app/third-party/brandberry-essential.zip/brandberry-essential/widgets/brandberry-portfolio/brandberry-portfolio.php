<?php

namespace BrandberryEssentialApp\Widgets;

use Elementor\Controls_Manager;
use Elementor\Group_Control_Background;
use Elementor\Group_Control_Image_Size;
use Elementor\Group_Control_Typography;
use Elementor\Widget_Base;

// Traits
$bb_root = dirname( __DIR__, 2 ) . '/';
require_once $bb_root . 'inc/traits/trait-bb-post-query.php';

use BrandberryEssentialApp\Traits\BB_Post_Query_Trait;

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Brandberry Portfolio (Brave)
 *
 * Focused implementation for the Brave/Webflow portfolio section (Grid/List tabs).
 *
 * Notes:
 * - Only Brandberry Portfolio Three skin is registered.
 * - Webflow CSS is scoped to the widget wrapper to avoid leaking styles globally.
 * - No GSAP/Flip extras (kept clean).
 */
class Brandberry_Portfolio extends Widget_Base {

	use BB_Post_Query_Trait;
	
	/** @var mixed */
	public $query;
	
	public function get_name() {
		return 'bb--portfolio';
	}

	public function get_title() {
		return esc_html__( 'Brandberry Portfolio', 'brandberry' );
	}

	public function get_icon() {
		return 'wcf eicon-gallery-grid';
	}

	public function get_categories() {
		return [ 'brandberry' ];
	}

	public function get_script_depends() {
		// Keep preview-safe: never read widget settings here.
		return [ 'bb--brave-portfolio-tabs' ];
	}

	public function get_style_depends() {
		// Scoped Webflow CSS for Brave portfolio only.
		return [ 'bb--brave-portfolio-scoped' ];
	}

	protected function _register_skins() {
		try {
			require_once __DIR__ . '/skins/skin-portfolio-base.php';
			require_once __DIR__ . '/skins/skin-brandberry-portfolio-three.php';

			$skin_class = '\\BrandberryEssentialApp\\Widgets\\BrandberryPortfolio\\Skin\\Skin_Brandberry_Portfolio_Three';
			if ( class_exists( $skin_class ) ) {
				$this->add_skin( new $skin_class( $this ) );
			}
		} catch ( \Throwable $e ) {
			if ( function_exists( 'error_log' ) ) {
				error_log( '[BrandberryEssential] Brave portfolio skin failed to load: ' . $e->getMessage() );
			}
		}
	}

	protected function register_controls() {
		$this->start_controls_section(
			'section_layout',
			[
				'label' => esc_html__( 'Layout', 'brandberry' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'bb_brave_tabs_mode',
			[
				'label'   => esc_html__( 'Tabs Mode', 'brandberry' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'both',
				'options' => [
					'both' => esc_html__( 'Grid + List (Tabs)', 'brandberry' ),
					'grid' => esc_html__( 'Grid Only', 'brandberry' ),
					'list' => esc_html__( 'List Only', 'brandberry' ),
				],
			]
		);

		$this->add_control(
			'bb_brave_default_tab',
			[
				'label'     => esc_html__( 'Default Tab', 'brandberry' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'grid',
				'options'   => [
					'grid' => esc_html__( 'Grid', 'brandberry' ),
					'list' => esc_html__( 'List', 'brandberry' ),
				],
				'condition' => [ 'bb_brave_tabs_mode' => 'both' ],
			]
		);

		$this->add_control(
			'bb_brave_caption',
			[
				'label'       => esc_html__( 'Caption', 'brandberry' ),
				'type'        => Controls_Manager::TEXTAREA,
				'default'     => "Projects of years\n©2021 — 2026",
				'placeholder' => "Projects of years\n©2021 — 2026",
			]
		);

		$this->add_responsive_control(
			'columns',
			[
				'label'          => esc_html__( 'Grid Columns', 'brandberry' ),
				'type'           => Controls_Manager::SELECT,
				// Desktop / Tablet / Mobile defaults.
				// These are applied via generated responsive CSS (see `selectors` below).
				'default'        => '4',
				'tablet_default' => '3',
				'mobile_default' => '1',
				'options'        => [
					'1' => '1',
					'2' => '2',
					'3' => '3',
					'4' => '4',
				],
				// IMPORTANT: Make the control truly responsive.
				// Elementor will output breakpoint-specific CSS that updates the CSS variable
				// used by the scoped Webflow stylesheet for the grid.
				'selectors'      => [
					'{{WRAPPER}} .bb-portfolio--brave' => '--bb-cols: {{VALUE}};',
				],
				'condition'      => [ 'bb_brave_tabs_mode!' => 'list' ],
			]
		);

		// Grid-only: choose how meta (title/arrow/categories) is positioned.
		$this->add_control(
			'bb_brave_grid_style',
			[
				'label'     => esc_html__( 'Portfolio Style (Grid)', 'brandberry' ),
				'type'      => Controls_Manager::SELECT,
				'default'   => 'style_1',
				'options'   => [
					'style_1' => esc_html__( '1 — Title/Arrow top + Categories bottom (inside image)', 'brandberry' ),
					'style_2' => esc_html__( '2 — Title/Arrow below image + Categories top (inside image)', 'brandberry' ),
					'style_3' => esc_html__( '3 — All below image (Title/Arrow row + Categories below)', 'brandberry' ),
				],
				'condition' => [ 'bb_brave_tabs_mode!' => 'list' ],
			]
		);

		$this->add_control(
			'posts_per_page',
			[
				'label'   => esc_html__( 'Posts Per Page', 'brandberry' ),
				'type'    => Controls_Manager::NUMBER,
				'min'     => 1,
				'max'     => 100,
				'default' => 6,
			]
		);

		$this->add_control(
			'post_taxonomy',
			[
				'label'       => esc_html__( 'Taxonomy (Labels)', 'brandberry' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => 'category',
				'placeholder' => 'category',
				'description' => esc_html__( 'Example: category, post_tag, portfolio_cat…', 'brandberry' ),
			]
		);

		$this->add_group_control(
			Group_Control_Image_Size::get_type(),
			[
				'name'    => 'thumbnail',
				'label'   => esc_html__( 'Image Resolution', 'brandberry' ),
				'default' => 'large',
			]
		);

		$this->end_controls_section();

		// Element visibility toggles.
		$this->start_controls_section(
			'section_elements',
			[
				'label' => esc_html__( 'Elements', 'brandberry' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			]
		);

		$this->add_control(
			'show_title',
			[
				'label'        => esc_html__( 'Show Title', 'brandberry' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'brandberry' ),
				'label_off'    => esc_html__( 'Hide', 'brandberry' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->add_control(
			'show_categories',
			[
				'label'        => esc_html__( 'Show Categories', 'brandberry' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'brandberry' ),
				'label_off'    => esc_html__( 'Hide', 'brandberry' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->add_control(
			'show_arrow',
			[
				'label'        => esc_html__( 'Show Arrow', 'brandberry' ),
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => esc_html__( 'Show', 'brandberry' ),
				'label_off'    => esc_html__( 'Hide', 'brandberry' ),
				'return_value' => 'yes',
				'default'      => 'yes',
			]
		);

		$this->end_controls_section();


		/**
		 * STYLE: Caption
		 */
		$this->start_controls_section(
			'section_style_bb_caption',
			[
				'label' => esc_html__( 'Caption', 'brandberry' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'bb_caption_typography',
				'selector' => '{{WRAPPER}} .bb-portfolio--brave .section-header-caption .caption',
			]
		);

		$this->add_control(
			'bb_caption_color',
			[
				'label'     => esc_html__( 'Text Color', 'brandberry' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .bb-portfolio--brave .section-header-caption .caption' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'bb_caption_background',
				'types'    => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .bb-portfolio--brave .section-header-caption .caption',

				'fields_options' => [
					'background' => [
						'default' => 'classic',
					],
					'color' => [
						'default' => '',
					],
					'image' => [
						'default' => [
							'url' => '',
							'id'  => '',
						],
					],
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name'     => 'bb_caption_border',
				'selector' => '{{WRAPPER}} .bb-portfolio--brave .section-header-caption .caption',
			]
		);

		$this->add_responsive_control(
			'caption_border_radius',
			[
				'label'      => esc_html__( 'Border Radius', 'brandberry' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', '%', 'em' ],
				'selectors'  => [
					'{{WRAPPER}} .bb-portfolio--brave .section-header-caption .caption' => 'border-radius: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'bb_caption_padding',
			[
				'label'      => esc_html__( 'Padding', 'brandberry' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .bb-portfolio--brave .section-header-caption .caption' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'bb_caption_margin',
			[
				'label'      => esc_html__( 'Margin', 'brandberry' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .bb-portfolio--brave .section-header-caption .caption' => 'margin: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->add_responsive_control(
			'bb_caption_align',
			[
				'label'   => esc_html__( 'Alignment', 'brandberry' ),
				'type'    => Controls_Manager::CHOOSE,
				'options' => [
					'left'   => [ 'title' => esc_html__( 'Left', 'brandberry' ), 'icon' => 'eicon-text-align-left' ],
					'center' => [ 'title' => esc_html__( 'Center', 'brandberry' ), 'icon' => 'eicon-text-align-center' ],
					'right'  => [ 'title' => esc_html__( 'Right', 'brandberry' ), 'icon' => 'eicon-text-align-right' ],
				],
				'selectors' => [
					'{{WRAPPER}} .bb-portfolio--brave .section-header-caption .caption' => 'text-align: {{VALUE}};',
				],
			]
		);

		$this->end_controls_section();

		/**
		 * STYLE: Title
		 */
		$this->start_controls_section(
		    'section_style_title',
		    [
		        'label'     => esc_html__( 'Title', 'brandberry' ),
		        'tab'       => Controls_Manager::TAB_STYLE,
		        'condition' => [ 'show_title' => 'yes' ],
		    ]
		);
		
		// Separate controls for Grid vs List.
		$this->start_controls_tabs( 'title_style_tabs' );
		
		/**
		 * GRID TAB
		 */
		$this->start_controls_tab(
		    'title_style_tab_grid',
		    [ 'label' => esc_html__( 'Grid', 'brandberry' ) ]
		);
		
		$this->add_group_control(
		    Group_Control_Typography::get_type(),
		    [
		        'name'     => 'title_typography_grid',
		        'selector' => '{{WRAPPER}} .bb-portfolio--brave .project-title, {{WRAPPER}} .bb-portfolio--brave .project-title a',
		    ]
		);
		
		$this->add_control(
		    'title_color_grid',
		    [
		        'label'     => esc_html__( 'Color', 'brandberry' ),
		        'type'      => Controls_Manager::COLOR,
		        'selectors' => [
		            '{{WRAPPER}} .bb-portfolio--brave .project-title' => 'color: {{VALUE}};',
		        ],
		    ]
		);
		
		$this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
		        'name'     => 'title_background_grid',
		        'types'    => [ 'classic', 'gradient' ],
		        'selector' => '{{WRAPPER}} .bb-portfolio--brave .project-title-wrapper',
		        'fields_options' => [
		            'background' => [
		                'default' => 'classic',
		            ],
		            'color' => [
		                'default' => '',
		            ],
		            'image' => [
		                'default' => [
		                    'url' => '',
		                    'id'  => '',
		                ],
		            ],
		        ],
		    ]
		);
		
		$this->end_controls_tab();
		
		/**
		 * LIST TAB
		 */
		$this->start_controls_tab(
		    'title_style_tab_list',
		    [ 'label' => esc_html__( 'List', 'brandberry' ) ]
		);
		
		// LIST TAB TYPOGRAPHY
		$this->add_group_control(
		    Group_Control_Typography::get_type(),
		    [
		        'name'     => 'title_typography_list',
		        'selector' => '{{WRAPPER}} .bb-portfolio--brave .projects-list-title, {{WRAPPER}} .bb-portfolio--brave .projects-list-title a',
		    ]
		);
		
		$this->add_control(
		    'title_color_list',
		    [
		        'label'     => esc_html__( 'Color', 'brandberry' ),
		        'type'      => Controls_Manager::COLOR,
		        'selectors' => [
		            '{{WRAPPER}} .bb-portfolio--brave .projects-list-title' => 'color: {{VALUE}};',
		        ],
		    ]
		);
		
		$this->add_group_control(
		    Group_Control_Background::get_type(),
		    [
		        'name'     => 'title_background_list',
		        'types'    => [ 'classic', 'gradient' ],
		        'selector' => '{{WRAPPER}} .bb-portfolio--brave .projects-list-column-first',
		        'fields_options' => [
		            'background' => [
		                'default' => 'classic',
		            ],
		            'color' => [
		                'default' => '',
		            ],
		            'image' => [
		                'default' => [
		                    'url' => '',
		                    'id'  => '',
		                ],
		            ],
		        ],
		    ]
		);
		
		$this->end_controls_tab();
		$this->end_controls_tabs();
		$this->end_controls_section();



			// NOTE: removed duplicate end_controls_* calls that caused Elementor warnings (PHP 8+).

		/**
		 * STYLE: Categories
		 */
		$this->start_controls_section(
			'section_style_categories',
			[
				'label'     => esc_html__( 'Categories', 'brandberry' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [ 'show_categories' => 'yes' ],
			]
		);

		// Separate controls for Grid vs List.
		$this->start_controls_tabs( 'categories_style_tabs' );

		// Grid tab.
		$this->start_controls_tab(
			'categories_style_tab_grid',
			[ 'label' => esc_html__( 'Grid', 'brandberry' ) ]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'categories_typography_grid',
				'selector' => '{{WRAPPER}} .bb-portfolio--brave .project-label-text',
			]
		);

		$this->add_control(
			'categories_color_grid',
			[
				'label'     => esc_html__( 'Text Color', 'brandberry' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .bb-portfolio--brave .project-label-text' => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'categories_background_grid',
				'types'    => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .bb-portfolio--brave .project-label',

				'fields_options' => [
					'background' => [
						'default' => 'classic',
					],
					'color' => [
						'default' => '',
					],
					'image' => [
						'default' => [
							'url' => '',
							'id'  => '',
						],
					],
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name'     => 'categories_border_grid',
				'selector' => '{{WRAPPER}} .bb-portfolio--brave .project-label',
			]
		);

		$this->add_responsive_control(
			'categories_padding_grid',
			[
				'label'      => esc_html__( 'Padding', 'brandberry' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .bb-portfolio--brave .project-label' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_tab();

		// List tab.
		$this->start_controls_tab(
			'categories_style_tab_list',
			[ 'label' => esc_html__( 'List', 'brandberry' ) ]
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			[
				'name'     => 'categories_typography_list',
				'selector' => '{{WRAPPER}} .bb-portfolio--brave .projects-list-categories, {{WRAPPER}} .bb-portfolio--brave .projects-list-categories div',
			]
		);

		$this->add_control(
			'categories_color_list',
			[
				'label'     => esc_html__( 'Text Color', 'brandberry' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .bb-portfolio--brave .projects-list-categories'      => 'color: {{VALUE}};',
					'{{WRAPPER}} .bb-portfolio--brave .projects-list-categories div'  => 'color: {{VALUE}};',
					'{{WRAPPER}} .bb-portfolio--brave .projects-list-comma'           => 'color: {{VALUE}};',
				],
			]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'categories_background_list',
				'types'    => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .bb-portfolio--brave .projects-list-categories > div',

				'fields_options' => [
					'background' => [
						'default' => 'classic',
					],
					'color' => [
						'default' => '',
					],
					'image' => [
						'default' => [
							'url' => '',
							'id'  => '',
						],
					],
				],
			]
		);

		$this->add_group_control(
			\Elementor\Group_Control_Border::get_type(),
			[
				'name'     => 'categories_border_list',
				'selector' => '{{WRAPPER}} .bb-portfolio--brave .projects-list-categories > div',
			]
		);

		$this->add_responsive_control(
			'categories_padding_list',
			[
				'label'      => esc_html__( 'Padding', 'brandberry' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => [ 'px', 'em', '%' ],
				'selectors'  => [
					'{{WRAPPER}} .bb-portfolio--brave .projects-list-categories > div' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->end_controls_section();

		/**
		 * STYLE: Arrow
		 */
		$this->start_controls_section(
			'section_style_arrow',
			[
				'label'     => esc_html__( 'Arrow', 'brandberry' ),
				'tab'       => Controls_Manager::TAB_STYLE,
				'condition' => [ 'show_arrow' => 'yes' ],
			]
		);

		$this->start_controls_tabs( 'arrow_style_tabs' );

		// Grid tab.
		$this->start_controls_tab(
			'arrow_style_tab_grid',
			[ 'label' => esc_html__( 'Grid', 'brandberry' ) ]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'arrow_background_grid',
				'types'    => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .bb-portfolio--brave .project-arrow',

				'fields_options' => [
					'background' => [
						'default' => 'classic',
					],
					'color' => [
						'default' => '',
					],
					'image' => [
						'default' => [
							'url' => '',
							'id'  => '',
						],
					],
				],
			]
		);

		$this->add_responsive_control(
			'arrow_size_grid',
			[
				'label'      => esc_html__( 'Arrow Icon Size', 'brandberry' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range'      => [ 'px' => [ 'min' => 8, 'max' => 64 ] ],
				'default'    => [ 'unit' => 'px', 'size' => 16 ],
				'selectors'  => [
					'{{WRAPPER}} .bb-portfolio--brave .project-arrow-image' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_tab();

		// List tab.
		$this->start_controls_tab(
			'arrow_style_tab_list',
			[ 'label' => esc_html__( 'List', 'brandberry' ) ]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'arrow_background_list',
				'types'    => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .bb-portfolio--brave .projects-list-arrow',

				'fields_options' => [
					'background' => [
						'default' => 'classic',
					],
					'color' => [
						'default' => '',
					],
					'image' => [
						'default' => [
							'url' => '',
							'id'  => '',
						],
					],
				],
			]
		);

		$this->add_responsive_control(
			'arrow_size_list',
			[
				'label'      => esc_html__( 'Arrow Icon Size', 'brandberry' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => [ 'px' ],
				'range'      => [ 'px' => [ 'min' => 8, 'max' => 64 ] ],
				'default'    => [ 'unit' => 'px', 'size' => 16 ],
				'selectors'  => [
					'{{WRAPPER}} .bb-portfolio--brave .projects-list-arrow-black' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
					'{{WRAPPER}} .bb-portfolio--brave .projects-list-arrow-white' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				],
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->end_controls_section();

		/**
		 * STYLE: List Row Background
		 */
		$this->start_controls_section(
			'section_style_list_row',
			[
				'label' => esc_html__( 'List Row', 'brandberry' ),
				'tab'   => Controls_Manager::TAB_STYLE,
				'condition' => [ 'bb_brave_tabs_mode!' => 'grid' ],
			]
		);

		$this->start_controls_tabs( 'list_row_bg_tabs' );

		$this->start_controls_tab(
			'list_row_bg_tab_normal',
			[ 'label' => esc_html__( 'Normal', 'brandberry' ) ]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'list_row_background',
				'types'    => [ 'classic', 'gradient' ],
				'selector' => '{{WRAPPER}} .bb-portfolio--brave .projects-list-inner',

				'fields_options' => [
					'background' => [
						'default' => 'classic',
					],
					'color' => [
						'default' => '',
					],
					'image' => [
						'default' => [
							'url' => '',
							'id'  => '',
						],
					],
				],
			]
		);

			$this->add_group_control(
				\Elementor\Group_Control_Border::get_type(),
				[
					'name'     => 'list_row_border',
					'selector' => '{{WRAPPER}} .bb-portfolio--brave .projects-list-inner',
				]
			);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'list_row_bg_tab_hover',
			[ 'label' => esc_html__( 'Hover', 'brandberry' ) ]
		);

		$this->add_group_control(
			Group_Control_Background::get_type(),
			[
				'name'     => 'list_row_background_hover',
				'types'    => [ 'classic', 'gradient' ],
					'selector' => '{{WRAPPER}} .bb-portfolio--brave .projects-list-link:hover .projects-list-inner',

				'fields_options' => [
					'background' => [
						'default' => 'classic',
					],
					'color' => [
						'default' => '',
					],
					'image' => [
						'default' => [
							'url' => '',
							'id'  => '',
						],
					],
				],
			]
		);

			$this->add_group_control(
				\Elementor\Group_Control_Border::get_type(),
				[
					'name'     => 'list_row_border_hover',
					'selector' => '{{WRAPPER}} .bb-portfolio--brave .projects-list-link:hover .projects-list-inner',
				]
			);

		$this->add_control(
			'list_row_text_color_hover',
			[
				'label'     => esc_html__( 'Text Color (Hover)', 'brandberry' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => [
					'{{WRAPPER}} .bb-portfolio--brave .projects-list-link:hover .projects-list-title' => 'color: {{VALUE}};',
					'{{WRAPPER}} .bb-portfolio--brave .projects-list-link:hover .projects-list-categories' => 'color: {{VALUE}};',
					'{{WRAPPER}} .bb-portfolio--brave .projects-list-link:hover .projects-list-categories > div' => 'color: {{VALUE}};',
					'{{WRAPPER}} .bb-portfolio--brave .projects-list-link:hover .projects-list-comma' => 'color: {{VALUE}};',
				],
			]
		);

		$this->end_controls_tab();
		$this->end_controls_tabs();

		$this->end_controls_section();


		// Keep the full query builder from the existing trait.
		$this->register_query_controls();
	}
}